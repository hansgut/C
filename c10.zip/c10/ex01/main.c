/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/04 19:35:12 by jcielesz          #+#    #+#             */
/*   Updated: 2024/02/04 19:49:43 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

void print_str(char *str, int code)
{
	while(*str)
	{
		write(code, str, 1);
		str++;
	}
}

void display_file(int file)
{
	char buff;

	while(read(file, &buff, 1) > 0)
		write(1, &buff, 1);
	if(read(file, &buff, 1) < 0)
	{
		print_str(strerror(errno), errno);
		print_str("\n", errno);
	}

}

int main(int argc, char **argv)
{
	int i;
	int file;

	i = 1;
	if (argc < 2)
		display_file(0);
	else
	{
		while (i < argc)
		{
			file = open(argv[i], O_RDONLY);
			if (file < 0)
			{

				print_str("ft_cat: ", errno);
				print_str(argv[i], errno);
				print_str(": ", errno);
				print_str(strerror( errno ), errno);
				print_str("\n", errno);
			}
			else
				display_file(file);
			close(file);
			i++;
		}
	}
	return (0);
}