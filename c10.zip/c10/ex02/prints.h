/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prints.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/04 23:50:57 by jcielesz          #+#    #+#             */
/*   Updated: 2024/02/05 00:33:59 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PRINTS_H
# define PRINTS_H
# include <errno.h>
# include <fcntl.h>
# include <stdlib.h>
# include <string.h>
# include <unistd.h>

int	ft_atoi(char *str)
{
	int	sum;
	int	sign;
	int	found;

	sum = 0;
	sign = 1;
	found = 1;
	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\f'
		|| *str == '\r')
		str++;
	if (*str == '-')
		sign = -1;
	if (*str == '-' || *str == '+')
		str++;
	while (*str && found)
	{
		if (*str >= '0' && *str <= '9')
			sum = sum * 10 + *str - '0';
		else
			found = 0;
		str++;
	}
	return (sign * sum);
}

void	print_str(char *str, int code)
{
	while (*str)
	{
		write(code, str, 1);
		str++;
	}
}

void	print_file_name(char *name)
{
	print_str("==> ", 1);
	print_str(name, 1);
	print_str(" <==\n", 1);
}

void	write_error(char *str, int err, int *was_error)
{
	print_str("ft_tail: ", err);
	print_str(str, err);
	print_str(": ", err);
	print_str(strerror(err), err);
	print_str("\n", err);
	*was_error = 1;
}
#endif