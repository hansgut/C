/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/04 23:02:33 by jcielesz          #+#    #+#             */
/*   Updated: 2024/02/05 01:00:42 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "prints.h"

void	display_file(int file, int bytes)
{
	char	buff;
	int		i;
	char	*buff_arr;

	buff_arr = (char *)malloc((bytes + 1) * sizeof(char));
	buff_arr[bytes + 1] = 0;
	while (read(file, &buff, 1) > 0)
	{
		i = 0;
		while (i < bytes - 1)
		{
			buff_arr[i] = buff_arr[i + 1];
			i++;
		}
		buff_arr[bytes - 1] = buff;
	}
	print_str(buff_arr, 1);
	if (read(file, &buff, 1) < 0)
	{
		print_str(strerror(errno), errno);
		print_str("\n", errno);
	}
	free(buff_arr);
}

void	proc_file(int file, int print_n, int bytes, char *filename)
{
	if (print_n)
		print_str("\n", 1);
	print_file_name(filename);
	display_file(file, bytes);
}

void	set_vars(int *i, int *was_error, int *bytes, char *c)
{
	*i = 3;
	*was_error = 0;
	*bytes = ft_atoi(c);
}

int	main(int argc, char **argv)
{
	int	i;
	int	file;
	int	bytes;
	int	was_error;

	if (argc < 4)
		return (0);
	set_vars(&i, &was_error, &bytes, argv[2]);
	while (i < argc)
	{
		file = open(argv[i], O_RDONLY);
		if (file >= 0)
		{
			if (argc == 4)
				display_file(file, bytes);
			else
				proc_file(file, (i < argc) && (i != 3), bytes, argv[i]);
		}
		else
			write_error(argv[i], errno, &was_error);
		close(file);
		i++;
	}
	return (was_error);
}
