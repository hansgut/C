#include <unistd.h>
#include <fcntl.h>

void file_display(int file)
{
	char c;

	while(read(file, &c, 1) != 0)
		write(1, &c, 1);
}

int main(int argc, char **argv)
{
	int file;
	if (argc > 2)
	{
		write(1, "Too many arguments.\n", 20);
		return (1);
	}
	if (argc < 2)
	{
		write(1, "File name missing.\n", 19);
		return (1);
	}
	file = open(argv[1], O_RDONLY);
	if (file == -1)
	{
		write(1, "Cannot read file.\n", 18);
		return (1);
	}
	file_display(file);
	close(file);
	return (0);
}
