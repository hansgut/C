/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/28 13:05:53 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/28 14:13:47 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int ft_strlen(char *str)
{
	int i;

	i = 0;
	while(str[i])
		i++;
	return (i);
}

char	*ft_strcpy(char *dest, char *src)
{
	int			i;

	i = 0;
	while(src[i])
	{
		dest[i] = src[i];
		i++;
	}
	return (dest);
}

char *ft_strdup(char *src)
{
	char *dest;

	dest = (char *) malloc(ft_strlen(src) * sizeof (char));

	return (ft_strcpy(dest, src));
}

int ft_total_len(int size, char **strs, char *sep)
{
	int i;
	int result;

	i = 0;
	result = 0;
	while(i < size)
	{
		result += ft_strlen(strs[i]);
		i++;
	}
	result += ft_strlen(sep) * (size - 1);
	return (result);
}

char *ft_strjoin(int size, char **strs, char *sep)
{
	char *result;
	int i;
	int j;
	int total_len;
	int iter;
	int iter_sep;

	if (sep == 0)
	{
		return NULL;
	}
	if(size <= 0)
	{
		result = (char* ) malloc(sizeof(char));
		result[0] = 0;
		return result;
	}
	if (size == 1)
		return (ft_strdup(strs[0]));
	total_len = ft_total_len(size, strs, sep);
	result = (char *) malloc(total_len * sizeof(char));
	i = 0;
	iter = 0;
	while(i < size)
	{
		j = 0;
		while(j < ft_strlen(strs[i]))
		{
			result[iter] = strs[i][j];
			j++;
			iter++;
		}
		iter_sep = 0;
		if (i < size - 1)
		{
			while(iter_sep < ft_strlen(sep))
			{
				result[iter] = sep[iter_sep];
				iter++;
				iter_sep++;
			}
		}
		i++;
	}
	return (result);
}