/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 13:28:42 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/28 12:54:21 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
//#include "ex00/ft_strdup.c"
//#include "ex01/ft_range.c"
#include "ex03/ft_strjoin.c"

int main() {
//	char s1[] = "Hello world!";
//	char *s2 = ft_strdup(s1);
//	printf("%s", s2);
//	free(s2);
//	int *a;
//	a = ft_range(3, 20);
//	for (int i = 0; i < 20-3; i++)
//		printf("%i ", a[i]);
	char *strings[] = {"Hello", "world", "how", "are", "you?"};
	char separator[] = ",,";

	// Determine the size of the strings array
	int size = sizeof(strings) / sizeof(strings[0]);

	// Call ft_strjoin function
	char *result = ft_strjoin(size, strings, separator);

	// Print the result
	printf("Joined String: %s\n", result);

	// Free dynamically allocated memory
	free(result);
	return 0;
}
