/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/28 12:44:26 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/28 13:00:15 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
int *ft_range(int min, int max)
{
	int *a;
	int i;

	if (min >= max)
		return NULL;

	a = malloc((max - min) * sizeof (int));
	i = 0;
	while(i < max - min)
	{
		a[i] = min + i;
		i++;
	}
	return a;
}
