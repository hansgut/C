/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:38:30 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 13:22:57 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_fibonacci(int index)
{
	if(index < 0)
		return (-1);
	if (index == 0)
		return (0);
	if (index == 1)
		return (1);

	return (ft_fibonacci(index - 1) + ft_fibonacci(index - 2));
}