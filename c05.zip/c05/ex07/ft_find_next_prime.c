/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 13:16:19 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 13:16:37 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_is_prime(int nb)
{
	int i;
	if (nb <= 1)
		return (0);
	i = 2;
	while (i < (nb / 2) + 1)
	{
		if ((nb % i) == 0)
			return (0);
		i++;
	}
	return (1);
}

int ft_find_next_prime(int nb)
{
	nb++;
	while(!ft_is_prime(nb))
		nb++;
	return (nb);
}