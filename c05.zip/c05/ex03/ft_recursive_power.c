/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:38:18 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 13:01:39 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_recursive_power(int nb, int power)
{
	if(power < 0 || nb == 0)
		return (0);
	if(power == 0 || nb == 1)
		return (1);

	return(nb * ft_recursive_power(nb, power - 1));
}