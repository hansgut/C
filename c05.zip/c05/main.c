/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:36:13 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 13:18:07 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ex00/ft_iterative_factorial.c"
#include "ex01/ft_recursive_factorial.c"
#include "ex02/ft_iterative_power.c"
#include "ex03/ft_recursive_power.c"
#include "ex04/ft_fibonacci.c"
#include "ex05/ft_sqrt.c"
#include "ex06/ft_is_prime.c"
#include "ex07/ft_find_next_prime.c"

int main() {
	// printf("%i", ft_iterative_factorial(-5));
	// printf("%i", ft_iterative_factorial(5));
	// printf("%i", ft_iterative_power(2, 6));
	// printf("%i", ft_recursive_power(2, 6));
	// printf("%i", ft_fibonacci(9));
	// printf("%i", ft_sqrt(144));
	// printf("%i", ft_is_prime(11));
	printf("%i", ft_find_next_prime(13));
	return 0;
}
