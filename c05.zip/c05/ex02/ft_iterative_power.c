/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 12:37:54 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 12:57:26 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int ft_iterative_power(int nb, int power)
{
	int i;
	int result;

	if(power < 0 || nb == 0)
		return (0);
	if(power == 0 || nb == 1)
		return (1);
	i = 0;
	result = nb;
	while(i < power - 1)
	{
		result *= nb;
		i++;
	}
	return (result);
}