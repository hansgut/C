/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/25 16:16:45 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/25 16:38:49 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *str)
{
	unsigned int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	pos;

	pos = ft_strlen(dest);
	if (size <= pos)
		return (pos);
	size--;
	while (pos < size && *src)
	{
		dest[pos++] = *src;
		src++;
	}
	dest[pos] = 0;
	return (pos);
}

// #include <stdio.h>
// int	main(void)
// {
// 	char str1[] = "Hello";
// 	char str2[] = " world!";
// 	int wynik = ft_strlcat(str1, str2, 20);
// 	printf("%i\n%s", wynik, str1);
// 	return (0);
// }