/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/26 23:41:51 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 02:06:49 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "ex00/ft_strlen.c"
#include "ex01/ft_putstr.c"
#include "ex02/ft_putnbr.c"
#include "ex03/ft_atoi.c"

int main() {
	char s[] = "Hello!";
	//printf("%i", ft_strlen(s));
	//ft_putstr(s);
	//ft_putnbr(10000000);
	printf("%i", ft_atoi("-+-+-123b45"));
	return 0;
}
