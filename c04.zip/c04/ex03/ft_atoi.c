/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/27 00:34:09 by jcielesz          #+#    #+#             */
/*   Updated: 2024/01/27 02:07:41 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int is_number(char c)
{
	if(c >= '0' && c <= '9')
		return 1;
	return 0;
}

int calc_sign(char *str)
{
	int i;
	int minus;

	i = 0;
	minus = 0;
	while(str[i] == '+' || str[i] == '-' || str[i] == ' ')
	{
		if(str[i] == '-')
			minus++;
		i++;
	}
	if (minus % 2 == 0)
		return (1);
	return (-1);
}

char *skip_chars(char *str)
{
	while(*str == '+' || *str == '-' || *str == ' ')
		str++;
	return str;
}

int ft_atoi(char *str)
{
	int i;
	int result;
	int sign;

	i = 0;
	result = 0;
	sign = calc_sign(str);
	str = skip_chars(str);
	while(str[i] && is_number(str[i]))
	{
		result += str[i] - '0';
		if (str[i + 1] == '\0' || !is_number(str[i + 1]))
			break;
		result *= 10;
		i++;
	}
	return result * sign;
}