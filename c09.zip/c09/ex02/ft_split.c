/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jcielesz <jcielesz@student.42warsaw.pl>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/28 17:18:16 by jcielesz          #+#    #+#             */
/*   Updated: 2024/02/04 18:14:06 by jcielesz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
int	check_sep(char c, char *charset)
{
	int	i;

	if (c == '\0')
		return (1);
	i = 0;
	while (charset[i])
	{
		if (c == charset[i])
			return (1);
		i++;
	}
	return (0);
}

int	count_words(char *str, char *charset)
{
	int	i;
	int	words;

	words = 0;
	i = 0;
	while (str[i])
	{
		if (check_sep(str[i + 1], charset) && !check_sep(str[i], charset))
			words++;
		i++;
	}
	return (words);
}

void	copy_word(char *dest, char *src, char *charset)
{
	int	i;

	i = 0;
	while (!check_sep(src[i], charset))
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = 0;
}

void get_words(char **strs, char *str, char *charset)
{
	int i;
	int j;
	int word;

	word = 0;
	i = 0;
	while (str[i])
	{
		if(check_sep(str[i], charset))
			i++;
		else
		{
			j = 0;
			while(!check_sep(str[i + j], charset))
				j++;
			strs[word] = (char *) malloc((j + 1) * sizeof(char));
			copy_word(strs[word], str + i, charset);
			i += j;
			word++;
		}
	}
}

char	**ft_split(char *str, char *charset)
{
	char	**array;
	int		words;

	words = count_words(str, charset);
	array = (char **)malloc(sizeof(char *) * (words + 1));
	array[words] = 0;
	get_words(array, str, charset);
	return (array);
}

#include <stdio.h>

int	main(void)
{
	char s[] = ";;;Hello,world,m;y,own";
	char charset[] = ",;";
	char **r;
	r = ft_split(s, "");
	for(int i = 0; i < count_words(s, charset) + 1; i++)
	{
		printf("%s\n", r[i]);
	}
	free(r);
	return 0;
}
