#ifndef FT_POINT_
#define FT_POINT_
typedef struct point
{
	int x;
	int y;
} t_point;
#endif