#ifndef FT_ABS_
#define FT_ABS_
#define ABS(Value) (Value < 0 ? -Value : Value)
#endif